package com.hexaware.app;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.hexaware.dao.FinanceRepositoryImpl;
import com.hexaware.entity.Expense;
import com.hexaware.entity.User;
import com.hexaware.myexceptions.ExpenseNotFoundException;
import com.hexaware.myexceptions.UserNotFoundException;

public class FinanceApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FinanceRepositoryImpl service = new FinanceRepositoryImpl();

        while (true) {
            System.out.println("\n--- Finance Management Menu ---");
            System.out.println("1. Add User");
            System.out.println("2. Add Expense");
            System.out.println("3. Delete User");
            System.out.println("4. Delete Expense");
            System.out.println("5. Update Expense");
            System.out.println("6. View Expenses (By User / All)");
            System.out.println("7. Exit");

            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Username: ");
                    String username = sc.next();
                    System.out.print("Password: ");
                    String password = sc.next();
                    System.out.print("Email: ");
                    String email = sc.next();
                    User user = new User(0, username, password, email);
                    System.out.println(service.createUser(user) ? "User added!" : "Failed to add user.");
                    break;

                case 2:
                    System.out.print("User ID: ");
                    int uid = sc.nextInt();
                    System.out.print("Amount: ");
                    double amount = sc.nextDouble();
                    System.out.print("Category ID: ");
                    int catId = sc.nextInt();
                    System.out.print("Date (yyyy-mm-dd): ");
                    String dateStr = sc.next();
                    System.out.print("Description: ");
                    sc.nextLine(); 
                    String desc = sc.nextLine();
                    Expense exp = new Expense(0, uid, amount, catId, Date.valueOf(dateStr), desc);
                    System.out.println(service.createExpense(exp) ? "Expense added!" : "Failed to add expense.");
                    break;

                case 3:
                    System.out.print("Enter User ID to delete: ");
                    int delUid = sc.nextInt();
                    try {
                        boolean deleted = service.deleteUser(delUid);
                        System.out.println(deleted ? "User deleted!" : "User not found.");
                    } catch (UserNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 4:
                    System.out.print("Enter Expense ID to delete: ");
                    int delExpId = sc.nextInt();
                    try {
                        boolean deleted = service.deleteExpense(delExpId);
                        System.out.println(deleted ? "Expense deleted!" : "Expense not found.");
                    } catch (ExpenseNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 5:
                    System.out.print("User ID: ");
                    int uId = sc.nextInt();
                    System.out.print("Expense ID to update: ");
                    int expId = sc.nextInt();
                    System.out.print("New Amount: ");
                    double newAmount = sc.nextDouble();
                    System.out.print("New Category ID: ");
                    int newCat = sc.nextInt();
                    System.out.print("New Date (yyyy-mm-dd): ");
                    String newDate = sc.next();
                    System.out.print("New Description: ");
                    sc.nextLine();
                    String newDesc = sc.nextLine();
                    Expense updated = new Expense(expId, uId, newAmount, newCat, Date.valueOf(newDate), newDesc);
                    try {
                        System.out.println(service.updateExpense(uId, updated) ? "Updated!" : "Update failed.");
                    } catch (ExpenseNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
           
                case 6:
                    System.out.println("1. View Expenses by User ID");
                    System.out.println("2. View All Expenses");
                    int subChoice = sc.nextInt();

                    try {
                        List<Expense> expenses;
                        if (subChoice == 1) {
                            System.out.print("Enter User ID: ");
                            int viewUid = sc.nextInt();
                            expenses = service.getAllExpenses(viewUid);
                        } else {
                            expenses = service.getAllExpenses();
                        }

                        for (Expense e : expenses) {
                            System.out.println("Expense ID: " + e.getExpenseId() + ", User ID: " + e.getUserId() +
                                               ", Amount: " + e.getAmount() + ", Date: " + e.getDate() +
                                               ", Category ID: " + e.getCategoryId() +
                                               ", Desc: " + e.getDescription());
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 7:
                    System.out.println("Exiting...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid option!");
            }
        }
    }
} 