package com.hexaware.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.entity.Expense;
import com.hexaware.entity.User;
import com.hexaware.myexceptions.ExpenseNotFoundException;
import com.hexaware.myexceptions.UserNotFoundException;
import com.hexaware.util.DBConnUtil;

public class FinanceRepositoryImpl implements IFinanceRepository {

    private Connection conn;

    public FinanceRepositoryImpl() {
        this.conn = DBConnUtil.getConnection("db.properties");
    }

    public boolean createUser(User user) {
        try {
            String query = "INSERT INTO Users (username, password, email) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean createExpense(Expense expense) {
        try {
            String query = "INSERT INTO Expenses (user_id, amount, category_id, date, description) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, expense.getUserId());
            ps.setDouble(2, expense.getAmount());
            ps.setInt(3, expense.getCategoryId());
            ps.setDate(4, expense.getDate());
            ps.setString(5, expense.getDescription());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteUser(int userId) throws UserNotFoundException {
        try {
            String query = "DELETE FROM Users WHERE user_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new UserNotFoundException("User not found with ID: " + userId);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new UserNotFoundException("Database error while deleting user.");
        }
    }

    public boolean deleteExpense(int expenseId) throws ExpenseNotFoundException {
        try {
            String query = "DELETE FROM Expenses WHERE expense_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, expenseId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new ExpenseNotFoundException("Expense not found with ID: " + expenseId);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExpenseNotFoundException("Database error while deleting expense.");
        }
    }


    public List<Expense> getAllExpenses(int userId) throws ExpenseNotFoundException {
        List<Expense> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM Expenses WHERE user_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Expense e = new Expense(
                    rs.getInt("expense_id"),
                    rs.getInt("user_id"),
                    rs.getDouble("amount"),
                    rs.getInt("category_id"),
                    rs.getDate("date"),
                    rs.getString("description")
                );
                list.add(e);
            }

            if (list.isEmpty()) throw new ExpenseNotFoundException("No expenses found for user ID: " + userId);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Expense> getAllExpenses() throws ExpenseNotFoundException {
        List<Expense> expenses = new ArrayList<>();
        try {
            String query = "SELECT * FROM Expenses";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Expense e = new Expense(
                    rs.getInt("expense_id"),
                    rs.getInt("user_id"),
                    rs.getDouble("amount"),
                    rs.getInt("category_id"),
                    rs.getDate("date"),
                    rs.getString("description")
                );
                expenses.add(e);
            }

            if (expenses.isEmpty()) {
                throw new ExpenseNotFoundException("No expenses found in the system.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return expenses;
    }

    public boolean updateExpense(int userId, Expense expense) throws ExpenseNotFoundException {
        try {
            String query = "UPDATE Expenses SET amount=?, category_id=?, date=?, description=? WHERE expense_id=? AND user_id=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setDouble(1, expense.getAmount());
            ps.setInt(2, expense.getCategoryId());
            ps.setDate(3, expense.getDate());
            ps.setString(4, expense.getDescription());
            ps.setInt(5, expense.getExpenseId());
            ps.setInt(6, userId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new ExpenseNotFoundException("Expense not found or unauthorized update.");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExpenseNotFoundException("Database error while updating expense.");
        }
    }
}

