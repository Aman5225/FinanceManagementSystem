package com.hexaware.dao;

import java.util.List;
import com.hexaware.entity.Expense;
import com.hexaware.entity.User;
import com.hexaware.myexceptions.ExpenseNotFoundException;
import com.hexaware.myexceptions.UserNotFoundException;

public interface IFinanceRepository {
    boolean createUser(User user);
    boolean createExpense(Expense expense);
    boolean deleteUser(int userId) throws UserNotFoundException;
    boolean deleteExpense(int expenseId) throws ExpenseNotFoundException;
    List<Expense> getAllExpenses(int userId) throws ExpenseNotFoundException;
    List<Expense> getAllExpenses() throws ExpenseNotFoundException;
    boolean updateExpense(int userId, Expense expense) throws ExpenseNotFoundException;
}
