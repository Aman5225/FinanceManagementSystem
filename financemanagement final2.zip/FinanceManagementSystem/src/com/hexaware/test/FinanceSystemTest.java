package com.hexaware.test;  

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hexaware.dao.FinanceRepositoryImpl;
import com.hexaware.entity.Expense;
import com.hexaware.entity.User;
import com.hexaware.myexceptions.ExpenseNotFoundException;

import java.sql.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FinanceSystemTest {

    static FinanceRepositoryImpl repo;

    @BeforeAll
    static void init() {
        repo = new FinanceRepositoryImpl();
    }

    @Test
    void testCreateUser() {
        User u = new User(0, "userA", "pwdA", "a@a.com");
        assertTrue(repo.createUser(u), "should create user");
    }

    @Test
    void testCreateExpense() {
        Expense e = new Expense(0, 1, 50.0, 1, Date.valueOf("2024-01-01"), "groceries");
        assertTrue(repo.createExpense(e), "should create expense");
    }

    @Test
    void testGetAllExpenses() throws ExpenseNotFoundException {
        List<Expense> list = repo.getAllExpenses(1);
        assertNotNull(list, "list shouldn’t be null");
    }
}
