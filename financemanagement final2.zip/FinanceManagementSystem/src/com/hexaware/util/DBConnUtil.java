package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnUtil {
    public static Connection getConnection(String propFile) {
        try {
            String connStr = DBPropertyUtil.getConnectionString(propFile);
            return DriverManager.getConnection(connStr);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
