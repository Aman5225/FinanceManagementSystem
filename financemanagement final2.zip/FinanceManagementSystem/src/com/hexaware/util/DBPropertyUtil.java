package com.hexaware.util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String fileName) {
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(fileName)) {
            if (input == null) {
                System.out.println("Sorry, unable to find " + fileName);
                return null;
            }

            Properties props = new Properties();
            props.load(input);

            String url = props.getProperty("url");
            String user = props.getProperty("user");
            String password = props.getProperty("password");

            return url + "?user=" + user + "&password=" + password;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}


